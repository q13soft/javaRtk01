package ru.rtk.java.hw.hw04;

public class App {
   public static void main(String[] args) {
        Tv tv01 = new Tv("Samsung", "ND201");
        Tv tv02 = new Tv("LG", "GR-V");

        tv01.nextProgram();
        tv01.infoAboutTv();
        tv02.infoAboutTv();

   }
    
}
