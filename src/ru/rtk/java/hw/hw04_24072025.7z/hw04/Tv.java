package ru.rtk.java.hw.hw04;

public class Tv {

    private String name;     // производитель
    private String model;    // модель
    private boolean status;  // true - вкл, false - выкл
    private String ledStatus;  // индекатор статуса  
    private int program;     // включенная активная программа 

/* 
 * 
*/
    public Tv(String name, String model) {
        this.setName(name);
        this.setModel(model);
        this.setStatus(false);
        this.setLedStatus("red");
        this.setProgram(0);
    }

    // включение/выключение телевизора
    public void pressPower() {
        if (this.isStatus()) {
            this.setStatus(false); // если включен, выключить
            this.setLedStatus("red"); // индикатор красный
        } else {
            this.setStatus(true); // если выключен включить 
            this.setLedStatus("green"); // индикатор зеленый
        }
    }
    // информация о телевизоре
    public void infoAboutTv() {
        System.out.print( "Телевизор " + this.getName() + " модель " + this.getModel());
        
        System.out.println();
        this.getStatus();
        this.getLedStatus();
        this.getProgram();

    }
    // переключить на следующую программа
    public void nextProgram() {
        if (this.program > 200) {
            this.setProgram(1); 
        } else {
            this.setProgram(this.getProgram()+1);
        }
    }
    // переключить на предыдущую программу
    public void prevProgram() {
        if (this.program < 1) {
            this.setProgram(200); 
        } else {
            this.setProgram(this.getProgram()-1);
        }
    }

    // if (this.program < 1 || this.program < 200) { }
    // установить программу
    public void setProgram(int program) {
        this.program = program;
    }

    public int getProgram() {
        return this.program;
    }



    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getModel() {
        return this.model;
    }

    public void setModel(String model) {
        this.model = model;
    }
    // узнать статус телевизора включен или нет
    public boolean isStatus() {
        return this.status;
    }
    // получить статус телефизора 
    public boolean getStatus() {
        return this.status;
    }
    /* изменить статус телевизора */
    public void setStatus(boolean status) {
        this.status = status;
    }

    /* изменить статус индикатора */
    public void setLedStatus(String ledStatus) {
        this.ledStatus = ledStatus;
    }
        
    public String getLedStatus() {
        return this.ledStatus;
    }    

    
}
